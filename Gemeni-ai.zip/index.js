const { GoogleGenerativeAI } = require("@google/generative-ai");
require("dotenv").config();
// const fs = require("fs");
const genAI = new GoogleGenerativeAI(process.env.API_KEY);

// const fs = require("fs");
// Access your API key as an enviroment variable (see "Set up your API key" above)
// const genAI = new GoogleGenerativeAI(process.env.API_KEY);
// console.log(model);
// Get information from prompt about every thing.
// async function run() {
//   const model = genAI.getGenerativeModel({ model: "gemini-pro" });
//   const prompt = "Write a story about a axe.";
//   const result = await model.generateContent(prompt);
//   const response = await result.response;
//   const text = response.text();
//   console.log(text);
// }
// run();

// Get information about picture by providing pictures to prompt
// function fileToGenerativePart(path, mimeType) {
//   return {
//     inlineData: {
//       data: Buffer.from(fs.readFileSync(path)).toString("base64"),
//       mimeType,
//     },
//   };
// }
// async function run() {
//   const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });
//   const prompt = "What's different between these pictures?";
//   const imageParts = [
//     fileToGenerativePart("NumanKhan.jpg", "image/jpeg"),
//     fileToGenerativePart("NumanKhan1.jpg", "image/jpeg"),
//   ];
//   const result = await model.generateContent([prompt, ...imageParts]);
//   const response = await result.response;
//   const text = response.text();
//   console.log(text);
// }
// run();

// Text to Chat:

async function run() {
  const model = genAI.getGenerativeModel({ model: "gemini-pro" });
  const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [
          {
            text: "Aslam-O-Aliykum, I have a Quran and Quran has 1200 pages ",
          },
        ],
      },
      {
        role: "model",
        parts: [{ text: "Great to meet you. What would you like to know?" }],
      },
    ],
    generationConfig: {
      maxOutputTokens: 100,
    },
  });

  const msg = "How many pages of Quran if I have 2 Quran?";
  const result = await chat.sendMessage(msg);
  const response = await result.response;
  const text = response.text();
  console.log(text);
}
run();

// Text-to-embedding

// async function run() {
//   const model = genAI.getGenerativeModel({ model: "embedding-001" });
//   const text = "The quick brown fox jumped over the electric car";
//   const result = await model.embedContent(text);
//   const embedding = result.embedding;
//   console.log(embedding);
// }
// run();
