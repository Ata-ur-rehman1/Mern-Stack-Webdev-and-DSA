import java.util.*;
class Lopps{
    public static void main(String args[]){
    
    System.out.print("number +  + i +  + " " + number*i");
}
}