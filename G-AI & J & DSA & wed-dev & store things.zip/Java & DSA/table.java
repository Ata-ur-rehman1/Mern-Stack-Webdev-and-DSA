import java.util.*;
class table{
    public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    int number = sc.nextInt();
    int n = 1;
    int m = 10;
    for(int i = n; int i <= m; i++){
    System.out.print(number + " X" + i + " =" + " " + number*i);
}
}
}
