const slider = document.querySelector("links");
const btn = document.querySelector(".btn");
if (slider != "none") {
  slider.style.display = "none";
} else {
  slider.style.display = "block";
}
