import mongoose, { Model, Schema } from "mongoose";

const sellerShcema = new mongoose.Schema({
  cnicorPassport: { type: String, required: true },
  postalCode: { type: String, required: true },
  address: { type: String, required: true },
  CrediteCard: { type: String, required: true },
  expireDate: { type: String, required: true },
  code: { type: String, required: true },
  addressCard: { type: String, required: true },
});

const sellerModel = new mongoose.Model("sellerForm", sellerShcema);

export default sellerModel;
