import mongoose from "mongoose";
const { ObjectId } = mongoose.Schema;

const reviewSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    rating: { type: Number, required: true },
    comment: { type: String, required: true },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  { timestamps: true }
);

const productSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    image: { type: String, required: true },
    brand: { type: String, required: true },
    quantity: { type: Number, required: true },
    category: { type: ObjectId, ref: "Category", required: true },
    description: { type: String, required: true },
    pdName2: { type: String },
    description2: { type: String, required: true },
    pdName3: { type: String },
    description3: { type: String, required: true },
    pdName4: { type: String },
    description4: { type: String, required: true },
    pdName5: { type: String },
    description5: { type: String, required: true },
    pdName6: { type: String },
    description6: { type: String, required: true },
    pdName7: { type: String },
    description7: { type: String, required: true },
    pdName8: { type: String },
    description8: { type: String, required: true },
    pdName9: { type: String },
    description9: { type: String, required: true },
    pdName10: { type: String },
    description10: { type: String, required: true },
    pdName11: { type: String },
    description11: { type: String, required: true },
    pdName12: { type: String },
    description12: { type: String, required: true },
    pdName13: { type: String },
    description13: { type: String, required: true },
    pdName14: { type: String },
    description14: { type: String, required: true },
    reviews: [reviewSchema],
    rating: { type: Number, required: true, default: 0 },
    numReviews: { type: Number, required: true, default: 0 },
    price: { type: Number, required: true, default: 0 },
    countInStock: { type: Number, required: true, default: 0 },
  },
  { timestamps: true }
);

const Product = mongoose.model("Product", productSchema);
export default Product;
